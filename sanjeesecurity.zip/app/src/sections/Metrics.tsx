import { useRef, useEffect, useState } from 'react';
import { motion, useInView, useSpring, useTransform } from 'framer-motion';
import { Shield, Users, Calendar, Award } from 'lucide-react';

interface CounterProps {
  value: number;
  suffix?: string;
  prefix?: string;
  duration?: number;
}

function Counter({ value, suffix = '', prefix = '', duration = 2 }: CounterProps) {
  const [hasAnimated, setHasAnimated] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  
  const springValue = useSpring(0, {
    stiffness: 50,
    damping: 30,
    duration: duration * 1000,
  });
  
  const displayValue = useTransform(springValue, (latest) => 
    Math.floor(latest)
  );
  
  useEffect(() => {
    if (isInView && !hasAnimated) {
      springValue.set(value);
      setHasAnimated(true);
    }
  }, [isInView, hasAnimated, springValue, value]);
  
  return (
    <span ref={ref} className="tabular-nums">
      {prefix}
      <motion.span>{displayValue}</motion.span>
      {suffix}
    </span>
  );
}

const metrics = [
  {
    id: 1,
    value: 22,
    suffix: '+',
    label: 'Years Experience',
    description: 'Elite protective service',
    icon: Calendar,
  },
  {
    id: 2,
    value: 137,
    suffix: '',
    label: 'Personnel Commanded',
    description: 'Large-scale operations',
    icon: Users,
  },
  {
    id: 3,
    value: 100,
    suffix: 'k+',
    label: 'Individuals Secured',
    description: 'Mass-scale event management',
    icon: Shield,
  },
  {
    id: 4,
    value: 5,
    suffix: '+',
    label: 'Executive Commendations',
    description: 'From Director, ADG, IG, DIG',
    icon: Award,
  },
];

export default function Metrics() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });
  
  return (
    <section 
      ref={sectionRef}
      className="relative py-24 sm:py-32 overflow-hidden"
    >
      {/* Full Width Glass Strip */}
      <motion.div
        initial={{ opacity: 0, scaleY: 0 }}
        animate={isInView ? { opacity: 1, scaleY: 1 } : {}}
        transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
        className="relative"
        style={{
          background: 'linear-gradient(180deg, rgba(255,255,255,0.02) 0%, rgba(255,255,255,0.05) 50%, rgba(255,255,255,0.02) 100%)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderTop: '1px solid rgba(255,255,255,0.08)',
          borderBottom: '1px solid rgba(255,255,255,0.08)',
        }}
      >
        {/* Background Glow */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[400px] h-[400px] bg-[#00F0FF]/10 rounded-full blur-[100px]" />
          <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[400px] h-[400px] bg-[#0066FF]/10 rounded-full blur-[100px]" />
        </div>
        
        <div className="section-container relative z-10 py-16 sm:py-24">
          {/* Section Label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center mb-12"
          >
            <span className="text-sm text-[#00F0FF] font-medium tracking-wider uppercase">
              Proven Track Record
            </span>
          </motion.div>
          
          {/* Metrics Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {metrics.map((metric, index) => {
              const Icon = metric.icon;
              return (
                <motion.div
                  key={metric.id}
                  initial={{ opacity: 0, y: 40 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ 
                    duration: 0.7, 
                    delay: 0.3 + index * 0.1,
                    ease: [0.4, 0, 0.2, 1]
                  }}
                  className="text-center group"
                >
                  {/* Icon */}
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-white/5 border border-white/10 mb-4 group-hover:bg-white/10 group-hover:border-[#00F0FF]/30 transition-all duration-300">
                    <Icon className="w-5 h-5 text-[#00F0FF]" />
                  </div>
                  
                  {/* Value */}
                  <div className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-2 gradient-text-accent">
                    <Counter 
                      value={metric.value} 
                      suffix={metric.suffix}
                    />
                  </div>
                  
                  {/* Label */}
                  <div className="text-base sm:text-lg font-medium text-white mb-1">
                    {metric.label}
                  </div>
                  
                  {/* Description */}
                  <div className="text-sm text-white/50">
                    {metric.description}
                  </div>
                </motion.div>
              );
            })}
          </div>
          
          {/* Bottom Tagline */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="text-center mt-12"
          >
            <p className="text-white/40 text-sm">
              Zero-fail security protocols derived from SPG and BSF operational excellence
            </p>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}
