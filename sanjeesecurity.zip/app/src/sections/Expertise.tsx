import { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { 
  Brain, 
  FileText, 
  Users2, 
  Scale, 
  Building2, 
  TrendingUp,
  Globe,
  Lightbulb,
  CheckCircle2
} from 'lucide-react';

const expertiseCategories = [
  {
    id: 1,
    title: 'Strategic Leadership',
    icon: Brain,
    skills: [
      'Strategic Thinking & Planning',
      'Policy Formulation & SOPs',
      'Stakeholder Management',
      'Executive Decision Making',
      'Conflict Resolution',
      'Crisis Leadership',
    ],
  },
  {
    id: 2,
    title: 'Technical Governance',
    icon: FileText,
    skills: [
      'Compliance Oversight',
      'Statutory Alignment',
      'Infrastructure Protection',
      'Asset Security',
      'Fiscal Stewardship',
      'Security Budgeting Models',
    ],
  },
  {
    id: 3,
    title: 'Operational Excellence',
    icon: Users2,
    skills: [
      'Multi-Site Operational Visibility',
      'Vendor Governance',
      'Audit Frameworks (TPRM)',
      'Geopolitical Risk Mitigation',
      'Intelligence-Driven Planning',
      'Human Capital Development',
    ],
  },
];

const certifications = [
  'Plant & Industrial Security',
  'Asset & Information Security',
  'Fire Prevention & Life Safety',
  'Civil Disaster Management',
  'Basic First Aid & Emergency Response',
  'VVIP Security',
  'SPG Specialized Training',
  'Tactical Operations',
  'GPS & Modern Navigation Systems',
  'Map Reading & Navigation Instruction',
  'Physical Training Instruction',
];

function SkillItem({ skill, index }: { skill: string; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      viewport={{ once: true }}
      className="flex items-center gap-3 group"
    >
      <div className="w-5 h-5 rounded-full bg-white/5 border border-white/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#00F0FF]/10 group-hover:border-[#00F0FF]/30 transition-all duration-300">
        <CheckCircle2 className="w-3 h-3 text-[#00F0FF]" />
      </div>
      <span className="text-white/70 group-hover:text-white transition-colors duration-300">
        {skill}
      </span>
    </motion.div>
  );
}

function ExpertiseCard({ 
  category, 
  index 
}: { 
  category: typeof expertiseCategories[0]; 
  index: number;
}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const isInView = useInView(cardRef, { once: true, margin: '-100px' });
  const Icon = category.icon;
  
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    setMousePosition({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };
  
  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ 
        duration: 0.7, 
        delay: index * 0.15,
        ease: [0.4, 0, 0.2, 1]
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => setMousePosition({ x: 0, y: 0 })}
      className="relative"
    >
      <div className="glass-card h-full p-6 sm:p-8 relative overflow-hidden group">
        {/* Spotlight Effect */}
        {mousePosition.x > 0 && mousePosition.y > 0 && (
          <div
            className="absolute pointer-events-none transition-opacity duration-300"
            style={{
              left: mousePosition.x - 100,
              top: mousePosition.y - 100,
              width: 200,
              height: 200,
              background: 'radial-gradient(circle, rgba(0, 240, 255, 0.15) 0%, transparent 70%)',
              opacity: 0.6,
            }}
          />
        )}
        
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-white/10 group-hover:border-[#00F0FF]/30 transition-all duration-300">
            <Icon className="w-6 h-6 text-[#00F0FF]" />
          </div>
          <h3 className="text-xl font-semibold">{category.title}</h3>
        </div>
        
        {/* Skills List */}
        <div className="space-y-3">
          {category.skills.map((skill, i) => (
            <SkillItem key={skill} skill={skill} index={i} />
          ))}
        </div>
      </div>
    </motion.div>
  );
}

export default function Expertise() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });
  
  return (
    <section 
      id="expertise"
      ref={sectionRef}
      className="relative py-24 sm:py-32"
    >
      {/* Background Glow */}
      <div className="absolute bottom-0 left-1/4 w-[500px] h-[500px] bg-[#00F0FF]/5 rounded-full blur-[150px] pointer-events-none" />
      
      <div className="section-container relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-px bg-[#00F0FF]" />
            <span className="text-sm text-[#00F0FF] font-medium tracking-wider uppercase">
              Technical Proficiencies
            </span>
          </div>
          
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            Strategic <span className="gradient-text-accent">Skillset</span>
          </h2>
          
          <p className="text-lg text-white/60 max-w-2xl">
            A comprehensive portfolio of capabilities spanning strategic leadership, 
            technical governance, and operational excellence forged through decades of elite service.
          </p>
        </motion.div>
        
        {/* Expertise Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {expertiseCategories.map((category, index) => (
            <ExpertiseCard 
              key={category.id} 
              category={category} 
              index={index}
            />
          ))}
        </div>
        
        {/* Certifications Section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <div className="glass-card p-8 sm:p-10">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                <Scale className="w-6 h-6 text-[#00F0FF]" />
              </div>
              <div>
                <h3 className="text-xl font-semibold">Specialized Training Portfolio</h3>
                <p className="text-white/60 text-sm">Certifications & Instructional Expertise</p>
              </div>
            </div>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {certifications.map((cert, index) => (
                <motion.div
                  key={cert}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: index * 0.03 }}
                  viewport={{ once: true }}
                  className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-[#00F0FF]/20 transition-all duration-300"
                >
                  <div className="w-2 h-2 rounded-full bg-[#00F0FF] flex-shrink-0" />
                  <span className="text-sm text-white/80">{cert}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
        
        {/* Key Strengths */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {[
            { icon: Globe, label: 'Geopolitical Risk', desc: 'High-threat territories' },
            { icon: Building2, label: 'Infrastructure', desc: 'Critical asset protection' },
            { icon: TrendingUp, label: 'Fiscal Stewardship', desc: 'Budget optimization' },
            { icon: Lightbulb, label: 'Innovation', desc: 'Data-driven decisions' },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div 
                key={item.label}
                className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/5"
              >
                <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-[#00F0FF]" />
                </div>
                <div>
                  <div className="font-medium text-sm">{item.label}</div>
                  <div className="text-xs text-white/50">{item.desc}</div>
                </div>
              </div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
