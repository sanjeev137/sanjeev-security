import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { 
  Shield, 
  TrendingUp, 
  Building2, 
  GraduationCap,
  Target,
  Lock,
  FileCheck
} from 'lucide-react';

const capabilities = [
  {
    id: 1,
    title: 'Strategic Security Leadership',
    description: '22+ years commanding elite units with expertise in high-stakes operational planning, resource optimization, and multi-site security architecture deployment across volatile corridors.',
    icon: Shield,
    size: 'large',
    gradient: 'from-[#00F0FF]/20 to-[#0066FF]/20',
  },
  {
    id: 2,
    title: 'Risk Management & Compliance',
    description: 'Enterprise risk governance aligned with EHS, QHSE standards, and statutory requirements. Ensuring protection strategies serve as value-add partners in regulated industrial environments.',
    icon: FileCheck,
    size: 'tall',
    gradient: 'from-[#0066FF]/20 to-[#7000FF]/20',
  },
  {
    id: 3,
    title: 'Crisis Leadership',
    description: 'Proven track record in disaster management, public order, and emergency coordination for large-scale events.',
    icon: Target,
    size: 'small',
    gradient: 'from-[#00F0FF]/15 to-transparent',
  },
  {
    id: 4,
    title: 'Infrastructure Protection',
    description: 'Securing nationally significant assets, sensitive corridors, and critical infrastructure with zero-fail protocols.',
    icon: Building2,
    size: 'small',
    gradient: 'from-[#7000FF]/15 to-transparent',
  },
  {
    id: 5,
    title: 'Human Capital Development',
    description: 'Institutional capability building through structured training academies, creating leadership pipelines and standardized certification pathways for security cadres.',
    icon: GraduationCap,
    size: 'wide',
    gradient: 'from-[#00F0FF]/10 via-[#0066FF]/10 to-[#7000FF]/10',
  },
  {
    id: 6,
    title: 'Fiscal Stewardship',
    description: 'Advanced proficiency in enterprise security budgeting models and vendor governance, managing large-scale outsourcing contracts.',
    icon: TrendingUp,
    size: 'small',
    gradient: 'from-[#0066FF]/15 to-transparent',
  },
  {
    id: 7,
    title: 'Elite Asset Protection',
    description: 'Nationally mandated high-protection protocols from SPG tenure, applicable to corporate high-value asset security.',
    icon: Lock,
    size: 'small',
    gradient: 'from-[#00F0FF]/15 to-transparent',
  },
];

function CapabilityCard({ 
  capability, 
  index 
}: { 
  capability: typeof capabilities[0]; 
  index: number;
}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(cardRef, { once: true, margin: '-100px' });
  
  const Icon = capability.icon;
  
  const sizeClasses = {
    large: 'md:col-span-2 md:row-span-2',
    tall: 'md:row-span-2',
    small: '',
    wide: 'md:col-span-2',
  };
  
  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 60 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ 
        duration: 0.7, 
        delay: index * 0.1,
        ease: [0.4, 0, 0.2, 1]
      }}
      className={`${sizeClasses[capability.size as keyof typeof sizeClasses]}`}
    >
      <div 
        className={`glass-card h-full p-6 sm:p-8 group relative overflow-hidden ${
          capability.size === 'large' ? 'min-h-[320px]' : 
          capability.size === 'tall' ? 'min-h-[400px]' : 
          capability.size === 'wide' ? 'min-h-[200px]' : 'min-h-[180px]'
        }`}
      >
        {/* Background Gradient */}
        <div 
          className={`absolute inset-0 bg-gradient-to-br ${capability.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
        />
        
        {/* Content */}
        <div className="relative z-10 h-full flex flex-col">
          {/* Icon */}
          <div className="mb-4">
            <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-white/10 group-hover:border-[#00F0FF]/30 transition-all duration-300">
              <Icon className="w-6 h-6 text-[#00F0FF]" />
            </div>
          </div>
          
          {/* Title */}
          <h3 className={`font-semibold mb-3 ${
            capability.size === 'large' ? 'text-2xl' : 'text-lg'
          }`}>
            {capability.title}
          </h3>
          
          {/* Description */}
          <p className={`text-white/60 leading-relaxed ${
            capability.size === 'large' ? 'text-base' : 'text-sm'
          }`}>
            {capability.description}
          </p>
          
          {/* Hover Indicator */}
          <div className="mt-auto pt-4 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <span className="text-xs text-[#00F0FF]">Learn more</span>
            <svg 
              className="w-4 h-4 text-[#00F0FF] transform group-hover:translate-x-1 transition-transform" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </div>
        </div>
        
        {/* Corner Accent */}
        <div className="absolute top-0 right-0 w-20 h-20 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
          <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-[#00F0FF]/50" />
        </div>
      </div>
    </motion.div>
  );
}

export default function Capabilities() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });
  
  return (
    <section 
      id="capabilities" 
      ref={sectionRef}
      className="relative py-24 sm:py-32"
    >
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[#0066FF]/5 rounded-full blur-[150px] pointer-events-none" />
      
      <div className="section-container relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-px bg-[#00F0FF]" />
            <span className="text-sm text-[#00F0FF] font-medium tracking-wider uppercase">
              Core Competencies
            </span>
          </div>
          
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            Strategic <span className="gradient-text-accent">Capabilities</span>
          </h2>
          
          <p className="text-lg text-white/60 max-w-2xl">
            Translating 22+ years of elite tactical command into corporate value propositions 
            focused on enterprise risk mitigation, fiscal stewardship, and strategic security orchestration.
          </p>
        </motion.div>
        
        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {capabilities.map((capability, index) => (
            <CapabilityCard 
              key={capability.id} 
              capability={capability} 
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
