import { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Linkedin, 
  Send,
  Shield,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';

export default function Contact() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
      setTimeout(() => {
        setIsSubmitted(false);
        setEmail('');
      }, 3000);
    }
  };
  
  return (
    <section 
      id="contact"
      ref={sectionRef}
      className="relative py-24 sm:py-32 overflow-hidden"
    >
      {/* Background Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[#00F0FF]/5 rounded-full blur-[200px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#0066FF]/5 rounded-full blur-[150px] pointer-events-none" />
      
      <div className="section-container relative z-10">
        {/* Main CTA */}
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
          className="text-center mb-16"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8"
          >
            <Shield className="w-4 h-4 text-[#00F0FF]" />
            <span className="text-sm text-white/70">Available for Consultancy</span>
          </motion.div>
          
          {/* Heading */}
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            Secure Your
            <br />
            <span className="gradient-text-accent">Infrastructure Today</span>
          </h2>
          
          <p className="text-lg text-white/60 max-w-xl mx-auto mb-10">
            Partner with 22+ years of elite security expertise. 
            From risk assessment to full-scale security architecture implementation.
          </p>
          
          {/* Email Capture Form */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="max-w-md mx-auto"
          >
            <form onSubmit={handleSubmit} className="relative">
              <div 
                className={`glass-card p-2 flex items-center gap-2 transition-all duration-300 ${
                  isFocused ? 'border-[#00F0FF]/40 shadow-[0_0_40px_rgba(0,240,255,0.15)]' : ''
                }`}
              >
                <div className="flex items-center gap-3 flex-1 pl-4">
                  <Mail className="w-5 h-5 text-white/40" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onFocus={() => setIsFocused(true)}
                    onBlur={() => setIsFocused(false)}
                    placeholder="Enter your email"
                    className="flex-1 bg-transparent text-white placeholder-white/40 outline-none text-sm py-3"
                    disabled={isSubmitted}
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSubmitted}
                  className={`cta-button py-3 px-6 flex items-center gap-2 ${
                    isSubmitted ? 'opacity-70' : ''
                  }`}
                >
                  {isSubmitted ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span className="text-sm">Sent!</span>
                    </>
                  ) : (
                    <>
                      <span className="text-sm">Get in Touch</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
            
            <p className="text-xs text-white/40 mt-4">
              Response within 24 hours. Confidentiality guaranteed.
            </p>
          </motion.div>
        </motion.div>
        
        {/* Contact Cards */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-16"
        >
          {[
            { 
              icon: Mail, 
              label: 'Email', 
              value: 'contact@sanjeev-security.com',
              href: 'mailto:contact@sanjeev-security.com'
            },
            { 
              icon: Phone, 
              label: 'Phone', 
              value: '+91 98XXX XXXXX',
              href: 'tel:+9198XXXXXXXX'
            },
            { 
              icon: MapPin, 
              label: 'Location', 
              value: 'New Delhi, India',
              href: '#'
            },
          ].map((contact) => {
            const Icon = contact.icon;
            return (
              <a
                key={contact.label}
                href={contact.href}
                className="glass-card p-6 group hover:border-[#00F0FF]/30 transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-[#00F0FF]/10 group-hover:border-[#00F0FF]/30 transition-all duration-300">
                    <Icon className="w-5 h-5 text-[#00F0FF]" />
                  </div>
                  <div>
                    <div className="text-sm text-white/50 mb-1">{contact.label}</div>
                    <div className="font-medium group-hover:text-[#00F0FF] transition-colors">
                      {contact.value}
                    </div>
                  </div>
                </div>
              </a>
            );
          })}
        </motion.div>
        
        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="border-t border-white/10 pt-8"
        >
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                <Shield className="w-5 h-5 text-[#00F0FF]" />
              </div>
              <div>
                <div className="font-semibold">Sanjeev</div>
                <div className="text-xs text-white/50">Security Consultancy</div>
              </div>
            </div>
            
            {/* Links */}
            <div className="flex items-center gap-6 text-sm text-white/50">
              <a href="#capabilities" className="hover:text-white transition-colors">Capabilities</a>
              <a href="#experience" className="hover:text-white transition-colors">Experience</a>
              <a href="#expertise" className="hover:text-white transition-colors">Expertise</a>
            </div>
            
            {/* Social */}
            <div className="flex items-center gap-3">
              <a 
                href="#" 
                className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 hover:border-[#00F0FF]/30 transition-all duration-300"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 hover:border-[#00F0FF]/30 transition-all duration-300"
              >
                <Send className="w-4 h-4" />
              </a>
            </div>
          </div>
          
          {/* Copyright */}
          <div className="text-center mt-8 pt-8 border-t border-white/5">
            <p className="text-xs text-white/30">
              © 2024 Sanjeev Security Consultancy. All rights reserved.
            </p>
            <p className="text-xs text-white/20 mt-2">
              Former SPG & BSF | Strategic Security Leadership
            </p>
          </div>
        </motion.footer>
      </div>
    </section>
  );
}
