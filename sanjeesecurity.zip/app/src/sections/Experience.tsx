import { useRef, useEffect, useState } from 'react';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { 
  Shield, 
  Star, 
  Award, 
  Users, 
  MapPin, 
  GraduationCap,
  Building,
  ChevronRight
} from 'lucide-react';

const timelineEvents = [
  {
    id: 1,
    year: '2002',
    title: 'Joined Border Security Force',
    description: 'Began distinguished career with BSF, quickly rising through ranks with exceptional performance in high-threat operational zones.',
    icon: Shield,
    highlights: ['Commissioned Officer', 'Border Governance'],
  },
  {
    id: 2,
    year: '2005',
    title: 'First Executive Commendation',
    description: 'Received commendation from Commandant for efficient command of 137 personnel and resource management in high-threat zones.',
    icon: Award,
    highlights: ['Resource Optimization', 'Command Discipline'],
  },
  {
    id: 3,
    year: '2008',
    title: 'Advanced Tactical Training',
    description: 'Completed specialized certifications in tactical operations, navigation systems, and physical security systems.',
    icon: GraduationCap,
    highlights: ['Tactical Operations', 'Navigation Systems'],
  },
  {
    id: 4,
    year: '2010',
    title: 'Special Protection Group Selection',
    description: 'Selected for elite SPG unit, executing nationally mandated high-protection protocols for highest-priority national assets.',
    icon: Star,
    highlights: ['VVIP Security', 'Elite Protection'],
  },
  {
    id: 5,
    year: '2012',
    title: 'House Protection Team Lead',
    description: 'Led House Protection Team operations, enforcing strict access control and procedural compliance across protected environments.',
    icon: Building,
    highlights: ['Access Control', 'Procedural Compliance'],
  },
  {
    id: 6,
    year: '2014',
    title: 'Duty Officer - COC Management',
    description: 'Directed Centralized Operations Center, managing surveillance integration, communication, and decision control frameworks.',
    icon: Shield,
    highlights: ['Surveillance Integration', 'Command Center'],
  },
  {
    id: 7,
    year: '2015',
    title: 'Senior Leadership Recognition',
    description: 'Received commendations from Inspector General for refined execution of complex organizational strategies.',
    icon: Award,
    highlights: ['Strategic Execution', 'Leadership Excellence'],
  },
  {
    id: 8,
    year: '2017',
    title: 'Instructor - STC Kashmir',
    description: 'Transitioned field expertise into institutional training academy, creating leadership pipelines for security cadres.',
    icon: Users,
    highlights: ['Training Academy', 'Capability Building'],
  },
  {
    id: 9,
    year: '2020',
    title: 'Mass-Scale Event Security',
    description: 'Directed security for Amarnath Yatra, managing safety of 100k+ individuals with large-scale logistics coordination.',
    icon: MapPin,
    highlights: ['Crowd Management', 'Logistics Coordination'],
  },
  {
    id: 10,
    year: '2023',
    title: 'Director-Level Recognition',
    description: 'Received commendations from Director and ADG for sustained excellence in mission-critical protective operations.',
    icon: Star,
    highlights: ['Operational Excellence', 'High-Pressure Leadership'],
  },
  {
    id: 11,
    year: 'Present',
    title: 'Security Consultancy',
    description: 'Bringing 22+ years of elite tactical command and corporate sophistication to enterprise protection strategies.',
    icon: Shield,
    highlights: ['Enterprise Security', 'Risk Governance'],
  },
];

function TimelineCard({ 
  event, 
  index,
  isActive 
}: { 
  event: typeof timelineEvents[0]; 
  index: number;
  isActive: boolean;
}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(cardRef, { once: true, margin: '-50px' });
  const Icon = event.icon;
  
  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, x: 60 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ 
        duration: 0.6, 
        delay: index * 0.08,
        ease: [0.4, 0, 0.2, 1]
      }}
      className="flex-shrink-0 w-[320px] sm:w-[380px]"
    >
      <div 
        className={`glass-card h-full p-6 relative overflow-hidden transition-all duration-500 ${
          isActive ? 'border-[#00F0FF]/40 shadow-[0_0_40px_rgba(0,240,255,0.15)]' : ''
        }`}
      >
        {/* Year Badge */}
        <div className="flex items-center justify-between mb-4">
          <span className="text-3xl font-bold gradient-text-accent">{event.year}</span>
          <div className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
            <Icon className="w-5 h-5 text-[#00F0FF]" />
          </div>
        </div>
        
        {/* Content */}
        <h3 className="text-lg font-semibold mb-3">{event.title}</h3>
        <p className="text-white/60 text-sm leading-relaxed mb-4">
          {event.description}
        </p>
        
        {/* Highlights */}
        <div className="flex flex-wrap gap-2">
          {event.highlights.map((highlight, i) => (
            <span 
              key={i}
              className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-white/70"
            >
              {highlight}
            </span>
          ))}
        </div>
        
        {/* Active Indicator */}
        {isActive && (
          <motion.div
            layoutId="activeIndicator"
            className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#00F0FF] to-[#0066FF]"
          />
        )}
      </div>
    </motion.div>
  );
}

export default function Experience() {
  const sectionRef = useRef<HTMLElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });
  const [activeIndex, setActiveIndex] = useState(0);
  
  const { scrollXProgress } = useScroll({
    container: scrollContainerRef,
  });
  
  const lineWidth = useTransform(scrollXProgress, [0, 1], ['0%', '100%']);
  
  // Update active index based on scroll
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;
    
    const handleScroll = () => {
      const scrollLeft = container.scrollLeft;
      const cardWidth = 400; // Approximate card width + gap
      const newIndex = Math.round(scrollLeft / cardWidth);
      setActiveIndex(Math.min(newIndex, timelineEvents.length - 1));
    };
    
    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);
  
  return (
    <section 
      id="experience"
      ref={sectionRef}
      className="relative py-24 sm:py-32 overflow-hidden"
    >
      {/* Background Glow */}
      <div className="absolute top-1/2 right-0 w-[600px] h-[600px] bg-[#7000FF]/10 rounded-full blur-[150px] -translate-y-1/2 pointer-events-none" />
      
      <div className="relative z-10">
        {/* Section Header */}
        <div className="section-container mb-12">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-px bg-[#00F0FF]" />
              <span className="text-sm text-[#00F0FF] font-medium tracking-wider uppercase">
                Career Journey
              </span>
            </div>
            
            <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
              <div>
                <h2 className="text-4xl sm:text-5xl font-bold mb-4">
                  Two Decades of <span className="gradient-text-accent">Excellence</span>
                </h2>
                <p className="text-lg text-white/60 max-w-2xl">
                  From BSF command to SPG elite protection, a journey of distinguished service 
                  and operational mastery across India's most sensitive security domains.
                </p>
              </div>
              
              {/* Scroll Hint */}
              <div className="flex items-center gap-2 text-white/40">
                <span className="text-sm">Scroll to explore</span>
                <ChevronRight className="w-4 h-4 animate-pulse" />
              </div>
            </div>
          </motion.div>
        </div>
        
        {/* Timeline Progress */}
        <div className="section-container mb-8">
          <div className="h-1 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-gradient-to-r from-[#00F0FF] to-[#0066FF]"
              style={{ width: lineWidth }}
            />
          </div>
        </div>
        
        {/* Horizontal Scroll Container */}
        <div 
          ref={scrollContainerRef}
          className="overflow-x-auto hide-scrollbar pb-8"
        >
          <div className="flex gap-6 px-6 sm:px-12 lg:px-[calc((100vw-1400px)/2+24px)]">
            {/* Timeline Line */}
            <div className="absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent pointer-events-none" />
            
            {timelineEvents.map((event, index) => (
              <TimelineCard 
                key={event.id} 
                event={event} 
                index={index}
                isActive={index === activeIndex}
              />
            ))}
            
            {/* End Card */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 1 }}
              className="flex-shrink-0 w-[200px] flex items-center justify-center"
            >
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#00F0FF]/20 to-[#0066FF]/20 border border-[#00F0FF]/30 flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-[#00F0FF]" />
                </div>
                <p className="text-white/60 text-sm">Your Security Partner</p>
              </div>
            </motion.div>
          </div>
        </div>
        
        {/* Year Markers */}
        <div className="section-container mt-8">
          <div className="flex justify-between text-xs text-white/30">
            <span>2002</span>
            <span>2008</span>
            <span>2014</span>
            <span>2020</span>
            <span>Present</span>
          </div>
        </div>
      </div>
    </section>
  );
}
