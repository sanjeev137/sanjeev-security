import { useRef, useEffect, useState } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { ChevronDown, Shield, Award, Users } from 'lucide-react';

function TiltCard() {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  const mouseXSpring = useSpring(x, { stiffness: 150, damping: 20 });
  const mouseYSpring = useSpring(y, { stiffness: 150, damping: 20 });
  
  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ['10deg', '-10deg']);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ['-10deg', '10deg']);
  
  const glareX = useTransform(mouseXSpring, [-0.5, 0.5], ['0%', '100%']);
  const glareY = useTransform(mouseYSpring, [-0.5, 0.5], ['0%', '100%']);
  
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const mouseX = (e.clientX - centerX) / (rect.width / 2);
    const mouseY = (e.clientY - centerY) / (rect.height / 2);
    
    x.set(mouseX * 0.5);
    y.set(mouseY * 0.5);
  };
  
  const handleMouseLeave = () => {
    setIsHovered(false);
    x.set(0);
    y.set(0);
  };
  
  return (
    <motion.div
      ref={cardRef}
      className="perspective-1000 relative"
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 1, delay: 0.8, ease: [0.4, 0, 0.2, 1] }}
    >
      <motion.div
        className="relative preserve-3d"
        style={{
          rotateX,
          rotateY,
          transformStyle: 'preserve-3d',
        }}
      >
        {/* Glass Card */}
        <div className="glass-card p-6 sm:p-8 w-full max-w-sm mx-auto relative overflow-hidden">
          {/* Glare Effect */}
          <motion.div
            className="absolute inset-0 pointer-events-none opacity-0 transition-opacity duration-300"
            style={{
              opacity: isHovered ? 0.15 : 0,
              background: `radial-gradient(circle at ${glareX.get()} ${glareY.get()}, rgba(255,255,255,0.8), transparent 50%)`,
            }}
          />
          
          {/* Profile Image */}
          <div className="relative mb-6">
            <div className="aspect-[3/4] rounded-2xl overflow-hidden bg-gradient-to-br from-[#00F0FF]/20 to-[#0066FF]/20">
              <img
                src="/profile-sanjeev.png"
                alt="Sanjeev - Security Consultant"
                className="w-full h-full object-cover object-top"
              />
            </div>
            
            {/* Badge */}
            <motion.div 
              className="absolute -bottom-3 -right-3 glass-card px-4 py-2 flex items-center gap-2"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 1.2, type: 'spring' }}
            >
              <Award className="w-4 h-4 text-[#00F0FF]" />
              <span className="text-xs font-medium">SPG Veteran</span>
            </motion.div>
          </div>
          
          {/* Info */}
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-1">Sanjeev</h3>
            <p className="text-white/60 text-sm mb-4">Elite Security Consultant</p>
            
            {/* Tags */}
            <div className="flex flex-wrap justify-center gap-2">
              <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs">
                Former SPG
              </span>
              <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs">
                BSF Commander
              </span>
              <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs">
                22+ Years
              </span>
            </div>
          </div>
          
          {/* Decorative Elements */}
          <div className="absolute top-4 left-4 w-2 h-2 rounded-full bg-[#00F0FF]/50" />
          <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-[#0066FF]/50" />
        </div>
        
        {/* Glow Behind Card */}
        <div 
          className="absolute -inset-4 -z-10 rounded-3xl opacity-40 blur-2xl"
          style={{
            background: 'linear-gradient(135deg, rgba(0, 240, 255, 0.3), rgba(0, 102, 255, 0.2))',
          }}
        />
      </motion.div>
    </motion.div>
  );
}

export default function Hero() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth - 0.5) * 20,
        y: (e.clientY / window.innerHeight - 0.5) * 20,
      });
    };
    
    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);
  
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24 pb-16">
      {/* Ambient Glow Orbs */}
      <motion.div 
        className="ambient-glow glow-cyan w-[600px] h-[600px] -top-48 -left-48"
        animate={{
          x: mousePosition.x * 2,
          y: mousePosition.y * 2,
        }}
        transition={{ type: 'spring', stiffness: 50, damping: 30 }}
      />
      <motion.div 
        className="ambient-glow glow-blue w-[500px] h-[500px] top-1/3 -right-48"
        animate={{
          x: mousePosition.x * -1.5,
          y: mousePosition.y * -1.5,
        }}
        transition={{ type: 'spring', stiffness: 50, damping: 30 }}
      />
      <motion.div 
        className="ambient-glow glow-purple w-[400px] h-[400px] bottom-0 left-1/3"
        animate={{
          x: mousePosition.x * 1,
          y: mousePosition.y * 1,
        }}
        transition={{ type: 'spring', stiffness: 50, damping: 30 }}
      />
      
      <div className="section-container relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left order-2 lg:order-1">
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8"
            >
              <Shield className="w-4 h-4 text-[#00F0FF]" />
              <span className="text-sm text-white/70">Strategic Security Leadership</span>
            </motion.div>
            
            {/* Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3, ease: [0.4, 0, 0.2, 1] }}
              className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6"
            >
              <span className="block">Absolute</span>
              <span className="block gradient-text-accent">Security.</span>
              <span className="block text-white/90">Fluid Intelligence.</span>
            </motion.h1>
            
            {/* Subheading */}
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="text-lg text-white/60 max-w-lg mx-auto lg:mx-0 mb-8 leading-relaxed"
            >
              22+ years of elite protective service and high-stakes governance. 
              Bridging the gap between field-tested leadership and corporate sophistication 
              for enterprise risk mitigation.
            </motion.p>
            
            {/* Stats Row */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex flex-wrap justify-center lg:justify-start gap-6 mb-10"
            >
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-[#00F0FF]" />
                <span className="text-sm text-white/70">137 Personnel Commanded</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-[#00F0FF]" />
                <span className="text-sm text-white/70">Multiple Commendations</span>
              </div>
            </motion.div>
            
            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="flex flex-wrap justify-center lg:justify-start gap-4"
            >
              <a href="#capabilities" className="cta-button">
                Explore Capabilities
              </a>
              <a href="#contact" className="glass-button">
                Get in Touch
              </a>
            </motion.div>
          </div>
          
          {/* Right Content - Profile Card */}
          <div className="order-1 lg:order-2 flex justify-center">
            <TiltCard />
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            className="flex flex-col items-center gap-2"
          >
            <span className="text-xs text-white/40">Scroll to explore</span>
            <ChevronDown className="w-5 h-5 text-white/40" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
